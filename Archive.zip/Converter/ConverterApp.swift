//
//  ConverterApp.swift
//  Converter
//
//  Created by Kunwardeep Singh on 2021-05-28.
//

import SwiftUI

@main
struct ConverterApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
