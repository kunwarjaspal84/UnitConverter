//
//  ContentView.swift
//  Converter
//
//  Created by Kunwardeep Singh on 2021-05-28.
//

import SwiftUI

struct ContentView: View {
    @State private var inputUnit = 0
    @State private var outputUnit = 0
    private let units = ["Litres","ML","Gallon","Cups","Pints"]
    @State private var value = ""
    var finalValue:Double{
       let computedValue = Double(value) ?? 0
        var interimValue = 0.0
        switch self.inputUnit {
        case 0:
            interimValue = computedValue
            break
        case 1:
            interimValue = computedValue / 1000
            break
        case 2:
            interimValue = computedValue * 3.785
            break
        case 3:
            interimValue = computedValue / 4.227
            break
        case 4:
            interimValue  = computedValue / 2.113
            break
        default:
            interimValue = computedValue
        }
        var returnValue = 0.0
        switch self.outputUnit {
        case 0:
            returnValue = interimValue
            break
        case 1:
            returnValue = interimValue * 1000
            break
        case 2:
            returnValue = interimValue / 3.785
            break
        case 3:
            returnValue = interimValue * 4.227
            break
        case 4:
            returnValue = interimValue * 2.113
            break
        default:
            returnValue = interimValue
        }
        
        return returnValue
    }
    var body: some View {
        NavigationView{
            Form{
                Section(header:Text("Enter the value to be converted")){
                    TextField("Enter the value here", text:$value)
                }
                Section(header:Text("Select the unit to convert from")){
                    Picker("Select the unit", selection:$inputUnit){
                        ForEach(0 ..< units.count){
                            Text("\(units[$0])")
                        }
                    }
                    .pickerStyle(SegmentedPickerStyle())
                    
                }
                Section(header:Text("Select the Unit to convert to")){
                    Picker("Select the unit", selection:$outputUnit){
                        ForEach(0 ..< units.count){
                            Text("\(units[$0])")
                        }
                    }
                    .pickerStyle(SegmentedPickerStyle())
                    
                }
                Section(header:Text("Converted Value is")){
                    Text("\(finalValue)")
                }
            }
            .navigationBarTitle("Converter")
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
